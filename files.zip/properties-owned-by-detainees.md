# Properties Owned by Detainees: Data, Ethics, and Visualization

## 1. **Definition & Scope**
- **Detainee:** An individual held in custody by authorities (e.g., ICE, police, other agencies).
- **Property Owned:** Real estate (homes, land, businesses) legally owned or co-owned by detainees, either directly or through family/trusts.

---

## 2. **Data Sources & Limitations**
- **Public Records:** Some property ownership is public (county assessor databases, tax rolls), but rarely linked directly to detention status.
- **Legal Proceedings:** Court or asset forfeiture documents may indicate property ties.
- **Aggregate Studies:** Research may estimate percentages of detainees owning property by region, nationality, or visa type.
- **Privacy:** Individual-level data is highly protected; only use aggregate or anonymized info.

---

## 3. **Ethical and Legal Considerations**
- Never publish or use PII (names, exact addresses).
- Use data only for legitimate research, advocacy, or policy purposes.
- Disclose data provenance and limitations clearly.
- Consider the risk of harm or stigmatization.

---

## 4. **Example Data Table (Aggregate/Anonymized)**

| Region         | Number of Detainees | % Owning Property | Type of Property (summary)     |
|----------------|---------------------|-------------------|-------------------------------|
| Southwest US   | 1,500               | 12%               | Mostly residential, some land |
| Northeast US   | 300                 | 9%                | Residential, small business   |
| Midwest US     | 450                 | 4%                | Land, few homes               |

---

## 5. **Visualization Ideas**
- **Heatmap:** Show regions with high overlap of property ownership and detainee populations.
- **Bar Charts:** Compare % property ownership by region, country of origin, or visa type.
- **Temporal Trends:** Show how property ownership among detainees changes over time.

---

## 6. **Sample Data Schema**

| Detainee Group   | Region        | Property Type   | Ownership Structure | % of Group Owning Property |
|------------------|--------------|-----------------|--------------------|---------------------------|
| ICE Detainees    | Texas        | Residential     | Direct/Family      | 10%                       |
| Student Visa Overstay | California | Business       | Joint/Trust        | 3%                        |

---

## 7. **Data Gathering Workflow**
1. Use public property records to estimate ownership patterns (by nationality, last known address, etc.).
2. Cross-reference aggregate detainee statistics (never individual names).
3. Summarize findings only at city/county/state/region level.

---

## 8. **Key Risks & Disclaimers**
- Data is often incomplete and should not be used to make assumptions about individuals.
- There may be confounding factors (property in family member's name, recent transfers, etc.).
- Always contextualize findings within the broader immigration and property rights landscape.

---

*If you need a data schema, code snippet for analysis, or a sample visualization template, let me know your preferred format!*