# Multilingual Glossary & False Friends Reference

## Purpose
This glossary helps prevent misinterpretation of key terms when visualizing or analyzing cross-lingual data on topics like crime, health, or identity. Use it for:
- Data labeling
- Map legends/annotations
- Human review of automated translations

---

## Example Table of False Friends

| Language | Term      | Literal Translation | True Meaning        | Common False Friend | Notes/Context                  |
|----------|-----------|--------------------|---------------------|--------------------|-------------------------------|
| Spanish  | molesto   | molested           | annoyed/bothered    | molest (EN)        | In English, “molest” is severe; Spanish is mild. |
| French   | assister  | to assist          | to attend           | assist (EN)        | “Assister à un concert” = “attend a concert.” |
| Italian  | parenti   | parents            | relatives           | parents (EN)       | “Genitori” = parents in Italian. |
| German   | Gift      | gift               | poison              | gift (EN)          | “Geschenk” = gift in German.   |
| Portuguese | pasta   | pasta              | folder              | pasta (EN/IT)      | “Massa” = pasta (food) in PT.  |

---

## How to Use

- **Annotate your maps/visualizations**: Add tooltips or info boxes for terms with potential false friends.
- **Data import/review**: Flag any dataset fields matching these terms for human review.
- **Translation pipelines**: Integrate this glossary for AI/human translators to cross-check.

---

## Add New Entries Below

| Language | Term      | Literal Translation | True Meaning        | Common False Friend | Notes/Context                  |
|----------|-----------|--------------------|---------------------|--------------------|-------------------------------|
|          |           |                    |                     |                    |                               |

---

## Resources

- [Wikipedia: List of False Friends](https://en.wikipedia.org/wiki/List_of_false_friends)
- [IATE EU Terminology](https://iate.europa.eu/home)
- [DeepL Glossary](https://www.deepl.com/glossary)

---

*Review this document with a language or subject-matter expert before deploying in sensitive or public-facing tools.*