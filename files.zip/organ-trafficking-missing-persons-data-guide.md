# Organ Trafficking, Missing Persons, Ages, Blood Types & Status Quo: Data Collection & Visualization Guide

## 1. **Organ Trafficking**
- **Definition:** Illegal trade of organs for transplantation.
- **Data Sources:**  
  - International organizations (WHO, UNODC)
  - National crime databases or human trafficking reports
  - Academic research and investigative journalism
- **Data Points:**  
  - Number of reported cases (by region)
  - Types of organs
  - Demographics (age, gender, nationality) if available in aggregate form
- **Ethics:**  
  - Use only anonymized, aggregate data.
  - Never reveal PII or operational details of ongoing investigations.

## 2. **Missing Persons**
- **Definition:** Individuals whose whereabouts are unknown and are reported missing.
- **Data Sources:**  
  - National missing persons registries (e.g., NamUs, Interpol Yellow Notices)
  - Law enforcement bulletins
- **Data Points:**  
  - Case number, date missing, age, last known location, gender
  - Status (open, found, closed)
- **Ethics:**  
  - Respect privacy—never publish names/PII without consent.
  - Use map visualizations with region/city-level granularity, not addresses.

## 3. **Ages**
- **Application:**  
  - Used for demographic analysis (both for missing persons and organ trafficking victims).
- **Data Points:**  
  - Age ranges/groups (e.g., child, adolescent, adult, elderly)
  - Aggregate counts

## 4. **Blood Types (People Needing Donations)**
- **Definition:** Individuals in need of blood donations, typically listed by blood banks, hospitals, or NGOs.
- **Data Sources:**  
  - National blood banks, Red Cross, hospital registries
- **Data Points:**  
  - Blood type (A, B, AB, O; Rh+/-)
  - Number of people in need by type and region
  - Urgency/priority (if available)
- **Ethics:**  
  - Never publish recipient names or identifiable data.
  - Only show aggregate demand per city/region.

## 5. **Status Quo**
- **Definition:** The prevailing state or baseline for any of the above topics (e.g., typical rates, expected numbers).
- **Application:**  
  - Use for trend analysis—compare current data to historical averages.
  - Provide context for interpreting spikes or anomalies.

---

## **Sample Data Table (Aggregate/Anonymized)**

| Region        | Missing Persons | Avg Age | Blood Type Need (A+/B-/O-/etc) | Organ Trafficking Cases | Status Quo (historical avg) |
|---------------|----------------|---------|-------------------------------|------------------------|-----------------------------|
| Southwest US  | 120            | 24      | O+: 18, A-: 5                 | 2                      | 110 missing/year            |
| Midwest US    | 80             | 31      | B+: 9, AB-: 1                 | 0                      | 75 missing/year             |

---

## **Visualization Ideas**
- **Heatmaps:** Incidence of missing persons, organ trafficking cases, or blood type needs by region.
- **Bar/Line Charts:** Age distribution, trends over time.
- **Status Quo Overlay:** Show current vs. historical averages for each metric.

---

## **Ethical & Legal Considerations**
- Do not use or display any PII.
- Be transparent about data sources, limitations, and aggregation methods.
- For “organ trafficking,” always note that data is likely incomplete due to underreporting.

---

## **Code/Data Integration Example**

If you want, I can provide:
- A Python template for aggregating and visualizing this data
- A sample schema for your database or data files
- Guidance on integrating with public data APIs

Let me know your preferred format or next step!