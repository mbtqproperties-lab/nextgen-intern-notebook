import pandas as pd

# Load your dataset and the false friends glossary
data = pd.read_csv('your_data.csv')  # Your main dataset
glossary = pd.read_csv('false_friends_glossary.csv')

# Flatten glossary words for quick matching
false_friend_words = set(glossary['Word'].str.lower())

# Flag rows where any cell contains a false friend
def flag_false_friend(row):
    return any(str(cell).lower() in false_friend_words for cell in row)

data['false_friend_flag'] = data.apply(flag_false_friend, axis=1)

# Filter flagged rows for review
flagged = data[data['false_friend_flag']]

# Output flagged rows for human review
flagged.to_csv('flagged_false_friends.csv', index=False)
print("Flagged rows saved to flagged_false_friends.csv")