# Surveillance & IoT: Human Tracking

## 1. **Surveillance Technologies Used by Agencies**
- **Cameras & Video Analytics:**  
  - Fixed cameras (CCTV) and mobile feeds (bodycams, drone video).
  - AI/ML models for facial recognition, movement tracking, and behavior analysis.
- **Cellular and Wi-Fi Tracking:**  
  - Use of IMSI-catchers (cell-site simulators like Stingray) to locate mobile phones.
  - Wi-Fi triangulation via public or private routers.
- **License Plate Readers (ALPR):**  
  - Automated cameras read and log license plates, cross-referenced with databases.
- **Biometric Sensors:**  
  - Facial, fingerprint, and sometimes gait recognition at border crossings, airports, and checkpoints.

## 2. **IoT Devices in Surveillance**
- **Smart Home Devices:**  
  - Smart doorbells (Ring, Nest), security cameras, and even smart speakers can provide data or video to authorities (sometimes via subpoena).
- **Wearable Devices:**  
  - Ankle monitors, smartwatches, or fitness trackers can be used for real-time location tracking.
- **Connected Vehicles:**  
  - Modern cars with GPS and telematics can be tracked or queried for location info.
- **Environmental Sensors:**  
  - Sensors for motion, sound, or environmental changes deployed in public or private spaces.

## 3. **Integration and Data Fusion**
- **Data Fusion Platforms:**  
  - Aggregate data from cameras, IoT, social media, and official records.
  - Use AI to identify patterns, “connect the dots,” and predict movement or associations.
- **Surveillance Drones:**  
  - Drones equipped with cameras, thermal sensors, and other IoT modules for remote surveillance.

## 4. **ICE and Law Enforcement Use Cases**
- **Locating Individuals:**  
  - Using phone, WiFi, and IoT data to locate targets for arrest or monitoring.
- **Geo-fencing:**  
  - Setting up virtual perimeters to alert when individuals enter/exit an area.
- **Monitoring Released Detainees:**  
  - Alternatives to detention often use ankle monitors (IoT), mobile apps, and voice check-ins.

## 5. **Privacy, Legal, and Ethical Risks**
- **Consent:**  
  - Most IoT data is collected with user consent, but law enforcement may access it via warrant, subpoena, or cooperation with companies.
- **Data Security:**  
  - IoT devices can be hacked, leading to unauthorized surveillance.
- **False Positives:**  
  - AI models can misidentify individuals, leading to wrongful detention or surveillance.
- **Chilling Effect:**  
  - People may avoid legal activity for fear of being tracked.

---

## **References & Further Reading**
- [EFF: Law Enforcement Access to Smart Home Data](https://www.eff.org/deeplinks/2020/01/ring-and-nest-help-surveillance-state-not-homeowners)
- [ACLU: ICE Use of Surveillance Tech](https://www.aclu.org/issues/privacy-technology/surveillance-technologies)
- [GAO: Federal Use of Facial Recognition](https://www.gao.gov/products/gao-21-518)

---

**If you want a technical breakdown (data pipeline, model, or code) of how IoT data could be used in such surveillance, just say the word!**