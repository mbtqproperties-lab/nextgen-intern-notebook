# Handling False Friends & Translation Pitfalls in Visualizations

## **What Are False Friends?**
- Words that look/sound alike in different languages but have different meanings.
  - **Example:**  
    - Spanish: **“molesto”** = “annoyed” or “bothered”
    - English: **“molest”** = sexual assault (much more severe)
  - Misinterpreting these can lead to incorrect data labeling or analysis.

---

## **Why Does This Matter?**
- **Data Misclassification:** When mapping topics like crime, surgery, or identity, a mistranslation can misrepresent the data (e.g., labeling “molesto” incidents as “molestations”).
- **Cultural Sensitivity:** Misunderstanding can cause offense or misinform policy decisions.
- **Legal/Ethical Risks:** Incorrect translation may lead to wrong conclusions in research or public reports.

---

## **How to Address This in Your Project**

### 1. **Translation Verification**
- Use **professional translation services** or trusted bilingual experts for key terms.
- Cross-check with **context**—not just word-for-word.

### 2. **Glossary of Key Terms**
- Maintain a glossary mapping important terms in all relevant languages, with explanations and usage context.
    - Example:
      | Language | Term      | True Meaning      | False Friend in English? |
      |----------|-----------|-------------------|-------------------------|
      | Spanish  | molesto   | annoyed/bothered  | molest (sexual assault) |
      | English  | cave      | natural hollow    | cava (wine cellar in ES)|

### 3. **Automated Flagging**
- Use NLP tools to flag potentially ambiguous terms and prompt a human review.
- Integrate translation APIs (e.g., Google Translate, DeepL) but always require human oversight for sensitive/critical categories.

### 4. **Contextual Annotations**
- Add tooltips or annotations in your visualizations explaining ambiguous terms, especially if your audience is multilingual.

### 5. **User Feedback**
- Allow users to report suspected mistranslations or request clarification directly in the interface.

---

## **Sample Implementation Step**

- When ingesting or labeling data, check for false friends:
    ```python
    false_friends = {
        "molesto": {"lang": "es", "actual": "annoyed", "common_misconception": "molest"},
        # Add more as needed
    }
    # If a term is flagged, require human review before display
    ```

---

## **Recommended Resources**
- [The List of Common False Friends (Wikipedia)](https://en.wikipedia.org/wiki/List_of_false_friends)
- [IATE (EU’s Inter-Active Terminology for Europe)](https://iate.europa.eu/home)
- [DeepL Glossary](https://www.deepl.com/glossary)

---

**Always review key terms for false friends—especially in crime, health, or identity data. When in doubt, check with a native speaker or expert!**