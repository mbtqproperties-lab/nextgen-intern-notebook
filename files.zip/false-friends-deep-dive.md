# Deep Dive: False Friends in Multilingual Data Projects

## 1. **What Are False Friends?**
False friends are words or phrases in different languages that look or sound similar but have different meanings, often leading to misunderstandings in translation and data interpretation.

---

## 2. **Types of False Friends**

### a) **Direct False Friends**
- Words that look/sound the same but mean something different.
  - Example:  
    - **Spanish:** “embarazada” (means “pregnant”)  
    - **English:** “embarrassed” (means “ashamed”)

### b) **Partial False Friends**
- Words with overlapping but not identical meanings.
  - Example:  
    - **German:** “bekommen” (means “to receive”)  
    - **English:** “become” (means “to turn into”)

### c) **Semantic Drift**
- Terms whose meanings have changed over time and diverge between languages.
  - Example:  
    - **French:** “préservatif” (means “condom”)  
    - **English:** “preservative” (means “food additive”)

---

## 3. **Risks in Data Projects**

- **Labeling Errors:** Mislabeling categories (e.g., “molesto” labeled as “molest” in crime data).
- **Misleading Analytics:** Incorrect aggregations or visualizations.
- **Cultural/Legal Sensitivity:** Offending users or violating data policies.
- **Automated Translation Issues:** NLP/ML models may propagate errors.

---

## 4. **Best Practices**

### a) **Comprehensive Glossary**
- Build an evolving glossary including:
  - False friend
  - Language pair
  - True meaning
  - Example in context
  - Danger level (e.g., “high risk” for legal/medical/confidential areas)

### b) **Contextual Validation**
- Always verify translations within the full sentence or scenario, not as isolated words.

### c) **Human-in-the-Loop**
- Flag high-risk terms for manual review by a native speaker or subject expert.

### d) **Automated Detection**
- Use NLP to scan for known false friends in translated datasets.
- Example:  
    ```python
    # Pseudocode
    for word in dataset:
        if word in false_friends_db:
            flag_for_review(word)
    ```

### e) **Annotation and Education**
- Annotate dashboards or visualizations with warnings or clarifications where false friends exist.

---

## 5. **Sample False Friends Glossary Expansion**

| Language 1 | Word  | Language 2 | Looks Like | Actual Meaning (L1) | Actual Meaning (L2) | Risk Context            | Example in L1                 | Example in L2                |
|------------|-------|------------|------------|---------------------|---------------------|-------------------------|-------------------------------|------------------------------|
| Spanish    | sopa  | English    | soup       | soup                | soap                | Health, nutrition       | “Comí sopa.” (I ate soup.)    | “I used soap.”               |
| French     | librairie | English | library    | bookstore           | library             | Education, retail       | “Je vais à la librairie.”     | “I’m going to the library.”  |
| Portuguese | pasta | English    | pasta      | folder/briefcase     | pasta (food)        | Business, food          | “Pegue a pasta na mesa.”      | “Cook the pasta.”            |
| German     | Rat   | English    | rat        | council/advice       | rodent              | Government, science     | “Der Rat der Stadt…”          | “A rat in the kitchen…”      |
| Italian    | casuale | English  | casual     | random/accidental    | relaxed style       | Fashion, statistics     | “Un incontro casuale.”        | “A casual outfit.”           |

---

## 6. **Technical Integration for Data Projects**

- **Glossary File:** Keep a YAML/JSON/CSV glossary in your repo for automated checks.
- **NLP Integration:** Use spaCy, NLTK, or custom scripts to check for glossary terms in text fields before translation or visualization.
- **Annotation Layer:** In visual dashboards, flag or annotate fields where false friends may mislead users.

---

## 7. **Open Source Resources**

- [Wiktionary: Category:False Friends](https://en.wiktionary.org/wiki/Category:False_friends_by_language)
- [Wikipedia: Lists of False Friends](https://en.wikipedia.org/wiki/List_of_false_friends)

---

## 8. **Next Steps**

- **Expand your glossary with your target language pairs.**
- **Integrate glossary checks into your ETL/data validation pipeline.**
- **Train your team and users on the risks of false friends in multilingual analysis.**

---

*Always combine automated and human review for critical or sensitive applications!*